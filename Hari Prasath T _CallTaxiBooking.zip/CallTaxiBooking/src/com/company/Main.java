package com.company;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Main {

    Map<Character, Integer> stations = new HashMap<Character, Integer>();

    public static void main(String[] args) {
        stations.put('A',1);
        stations.put('B',2);
        stations.put('C',3);
        stations.put('D',4);
        stations.put('E',5);
        int noOfTaxis = 5;
        ArrayList<Taxi> taxis = new ArrayList<Taxi>(noOfTaxis);
        ArrayList<Booking> bookings = new ArrayList<Booking>();

        //Creating taxis
        for (int taxiId=1;taxiId<noOfTaxis;taxiId++) {
            taxis.add(new Taxi("taxi "+taxiId));
        }

        Scanner sc = new Scanner(System.in);

        int choice;

        while(true)
        {
            System.out.println("__________CallTaxiBooking___________");
            System.out.println("1.Booking");
            System.out.println("2.Taxi Details");
            System.out.println("3.Exit");
            System.out.println("Enter ur choice:");
            choice = sc.nextInt();

            char startPoint;
            char destPoint;
            Date starttime = null;
            Integer customerId;
            Integer endtime = null;


            switch (choice)
            {
                case 1:

                    System.out.println("Customer ID : ");
                    Customer customer = new Customer();
                    customerId = sc.nextInt();
                    customer.setCustomerId(customerId);




                    System.out.println("Starting Point :");
                    startPoint = sc.next().charAt(0);
                    System.out.println("Destination Point : ");
                    destPoint = sc.next().charAt(0);
                    if(startPoint < 'A' || destPoint > 'E' || startPoint > 'E' || destPoint < 'A')
                    {
                        System.out.println("Valid pickup and drop points are A, B, C, D, E.");
                        return;
                    }
                    System.out.println("Time (HH.mm: ");
                    sc.nextLine();
                    String strTime = sc.nextLine();
                    SimpleDateFormat tempTime = new SimpleDateFormat("hh.mm a");
                    try {
                        starttime = tempTime.parse(strTime);
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                    Taxi allocatedTaxi = allocateTaxi(taxis, startPoint ,starttime);

                    //Calculating End Time
                    Date endTime = ((stations.get(allocatedTaxi.currStation) - stations.get(startPoint))*15);

                    Booking booking = new Booking(startPoint, destPoint, starttime , endTime, customer, allocatedTaxi);
                    allocatedTaxi.bookings.add(booking);
                    bookings.add(booking);
                    booking.printBookingDetails();
                    break;

                case 2:
                    String taxiId = sc.nextLine();
                    for(Taxi t : taxis){
                        if(t.taxiNo == taxiId){
                            for(Booking b : t.bookings){
                                System.out.println(b.getCustomer().customerId);
                                System.out.println(b.getStartPoint());
                                System.out.println(b.getDestPoint());
                                System.out.println(b.getStarTime());
                                System.out.println(b.getEndTime());
                                System.out.println(b.getFare());
                            }
                        }
                    }
                    break;
                default:
                    return;
            }
        }


    }

    private static Taxi allocateTaxi(ArrayList<Taxi> taxis, char startPoint , Date pickTime) {

        ArrayList<Taxi> taxi = new ArrayList<>();
        Integer shortestDistance = 6;
        ArrayList<Taxi> allocatedTaxis = new ArrayList<Taxi>();

        for(Taxi t : taxis)
        {
            Integer taxiCurrPosition = (Integer) stations.get(t.currStation);
            Integer customerCurrPosition = (Integer) stations.get(startPoint);
            Map<Taxi, Integer> taxiTravelingDistance = new HashMap<Taxi, Integer>();
            if(taxiCurrPosition > customerCurrPosition){
                ArrayList<Character> keys = new ArrayList<Character>(stations.keySet());
                Integer traveledDistance = 0;
                for(int i=taxiCurrPosition; i>0;i--){
                    Integer position = stations.get(keys.get(i));
                    traveledDistance += taxiCurrPosition - position;
                }
                taxiTravelingDistance.put(t, traveledDistance);
                if(traveledDistance<shortestDistance){
                    shortestDistance = traveledDistance;
                }
            } else if(taxiCurrPosition < customerCurrPosition){
                ArrayList<Character> keys = new ArrayList<Character>(stations.keySet());
                Integer traveledDistance = 0;

                for(int i=1; i>=taxiCurrPosition;i++){
                    Interger position = stations.get(keys.get(i));
                    traveledDistance += taxiCurrPosition + position;
                }
                taxiTravelingDistance.put(t, traveledDistance);
                if(traveledDistance<shortestDistance){
                    shortestDistance = traveledDistance;
                }
            }
            for(int i=0; i<=5;i++){
                Integer traveledDistance = taxiTravelingDistance.get(taxiTravelingDistance.get(i));
                if(traveledDistance == shortestDistance){
                    allocatedTaxis.add();
                }
            }
            Boolean isAvailable = checkTaxiAvailability(t, pickTime);
            if(isAvailable){

                if(){
                    taxi.add(t);
                }

            }
        }

    }

    private static char getNearestStation(Taxi t,char startPoint,char nearestStation){
        int nearestPoint;


    }

    private static boolean isNearest(Taxi t, char startPoint) {

        Integer currPosition = stations.get(startPoint);

        if(currPosition )
    }

    private static Boolean checkTaxiAvailability(Taxi taxi, Date pickTime) {
        ArrayList<Booking> bookings = taxi.getBookings();
        if(bookings.size()==0){
            return true;
        }
        for(Booking booking : taxi.getBookings()) {
            if(booking.getEndTime().compareTo(pickTime )<0){
                return true;
            }
        }
        return false;
    }

}
