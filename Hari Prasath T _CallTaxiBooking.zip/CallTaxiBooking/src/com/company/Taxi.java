package com.company;

import java.util.ArrayList;

public class Taxi {
    String taxiNo;
    char currStation = 'A';
    int earnings = 0;

    public ArrayList<Booking> getBookings() {
        return bookings;
    }

    public void setBookings(ArrayList<Booking> bookings) {
        this.bookings = bookings;
    }

    ArrayList<Booking> bookings = new ArrayList<>();

    public Taxi(String taxiNo) {
        this.taxiNo = taxiNo;
    }
}
