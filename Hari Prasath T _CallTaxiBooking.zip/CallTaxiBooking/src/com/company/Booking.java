package com.company;

import java.util.Date;

public class Booking {
    private char startPoint;
    private char destPoint;
    private Date starTime;
    private Date endTime;
    private Integer fare;
    private Integer distance;
    private Customer customer;
    private Taxi taxi;

    public char getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(char startPoint) {
        this.startPoint = startPoint;
    }

    public char getDestPoint() {
        return destPoint;
    }

    public void setDestPoint(char destPoint) {
        this.destPoint = destPoint;
    }

    public Date getStarTime() {
        return starTime;
    }

    public void setStarTime(Date starTime) {
        this.starTime = starTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public Integer getFare() {
        return fare;
    }

    public void setFare(Integer fare) {
        this.fare = fare;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(Integer distance) {
        this.distance = distance;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Taxi getTaxi() {
        return taxi;
    }

    public void setTaxi(Taxi taxi) {
        this.taxi = taxi;
    }

    public Date getEndTime() {
        return endTime;
    }

    public Booking(char startPoint, char destPoint, Date starTime, Date endTime, Customer customer, Taxi taxi) {
        this.startPoint = startPoint;
        this.destPoint = destPoint;
        this.starTime = starTime;
        this.endTime = endTime;
        this.customer = customer;
        this.taxi = taxi;
    }

    public void printBookingDetails()
    {
        Customer customer = new Customer();
        System.out.println("Booking ID : "+customer.getCustomerId());
        System.out.println("Allotted Taxi : ");
    }

}
