package com.company;

import java.util.ArrayList;

public class Customer {
    int customerId;
    ArrayList<Booking> bookings;

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
}
